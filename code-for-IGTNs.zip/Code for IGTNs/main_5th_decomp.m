% This code is used for fifth-order speech tensor construction and
% decomposition. 

clear, clc;
close all;

% load data
load normal_data;
load unnormal_data;
 
Alldata=[normal_data; unnormal_data];
L=length(Alldata);
Fifth_tensor=zeros(25,30,30,5,3);
Fourth_a=zeros(25,30,30,5);
Fourth_o=zeros(25,30,30,5);
Fourth_e=zeros(25,30,30,5);
label=[ones(1,40),zeros(1,46)];
num1=40;
num2=46;

% Hyperparameters
opts = [];
opts.tol   = 0.05;
opts.rho   = 0.1;
opts.maxit = 50;
opts.R = [1 1 1 1 1;
          2 2 2 2 2]; 
addpath(genpath([pwd,'/lib_IGTN']));
Features=zeros(opts.R(2,1)*opts.R(2,2)*opts.R(2,3)*opts.R(2,4)*opts.R(2,5),86);
error=zeros(1,86); 

for i=1:L
    % tensor constrcution
    fprintf('\tSubjectnum %d ', i);
    a=Alldata{i,1};
    L_stand=400000;
    fs=22050;
    
    % Resample signals to the same length
    L_a=length(a);
    re_fs=round(L_stand/L_a*fs);
    a=resample(a,re_fs,fs);
    a=a./max(abs(a));
    
    o=Alldata{i,2};
    L_o=length(o);
    re_fs=round(L_stand/L_o*fs);
    o=resample(o,re_fs,fs);
    o=o./max(abs(o));
    
    e=Alldata{i,3};
    L_e=length(e);
    re_fs=round(L_stand/L_e*fs);
    e=resample(e,re_fs,fs);
    e=e./max(abs(e));
    
    % Fifth-order speech tensor contruction
    window=fix(length(a)/500);
    S_a=spectrogram(a,window,400,512,44100);
    S_a=abs(real(S_a));
    S_a1=S_a(1:25,1:900);
    S_a2=S_a(26:50,1:900);
    S_a3=S_a(51:75,1:900);
    S_a4=S_a(76:100,1:900);
    S_a5=S_a(101:125,1:900);
    tensor_a1=reshape(S_a1,[25 30 30]);
    tensor_a1=tensor_a1./max(tensor_a1(:));
    tensor_a2=reshape(S_a2,[25 30 30]);
    tensor_a2=tensor_a2./max(tensor_a2(:));
    tensor_a3=reshape(S_a3,[25 30 30]);
    tensor_a3=tensor_a3./max(tensor_a3(:));
    tensor_a4=reshape(S_a4,[25 30 30]);
    tensor_a4=tensor_a4./max(tensor_a4(:));
    tensor_a5=reshape(S_a5,[25 30 30]);
    tensor_a5=tensor_a5./max(tensor_a5(:));
    Fourth_a(:,:,:,1)=tensor_a1;
    Fourth_a(:,:,:,2)=tensor_a2;
    Fourth_a(:,:,:,3)=tensor_a3;
    Fourth_a(:,:,:,4)=tensor_a4;
    Fourth_a(:,:,:,5)=tensor_a5;
    
    S_o=spectrogram(o,window,400,512,44100);
    S_o=abs(real(S_o));
    S_o1=S_o(1:25,1:900);
    S_o2=S_o(26:50,1:900);
    S_o3=S_o(51:75,1:900);
    S_o4=S_o(76:100,1:900);
    S_o5=S_o(101:125,1:900);
    tensor_o1=reshape(S_o1,[25 30 30]);
    tensor_o1=tensor_o1./max(tensor_o1(:));
    tensor_o2=reshape(S_o2,[25 30 30]);
    tensor_o2=tensor_o2./max(tensor_o2(:));
    tensor_o3=reshape(S_o3,[25 30 30]);
    tensor_o3=tensor_o3./max(tensor_o3(:));
    tensor_o4=reshape(S_o4,[25 30 30]);
    tensor_o4=tensor_o4./max(tensor_o4(:));
    tensor_o5=reshape(S_o5,[25 30 30]);
    tensor_o5=tensor_o5./max(tensor_o5(:));
    Fourth_o(:,:,:,1)=tensor_o1;
    Fourth_o(:,:,:,2)=tensor_o2;
    Fourth_o(:,:,:,3)=tensor_o3;
    Fourth_o(:,:,:,4)=tensor_o4;
    Fourth_o(:,:,:,5)=tensor_o5;
    
    S_e=spectrogram(e,window,400,512,44100);
    S_e=abs(real(S_e));
    S_e1=S_e(1:25,1:900);
    S_e2=S_e(26:50,1:900);
    S_e3=S_e(51:75,1:900);
    S_e4=S_e(76:100,1:900);
    S_e5=S_e(101:125,1:900);
    tensor_e1=reshape(S_e1,[25 30 30]);
    tensor_e1=tensor_e1./max(tensor_e1(:));
    tensor_e2=reshape(S_e2,[25 30 30]);
    tensor_e2=tensor_e2./max(tensor_e2(:));
    tensor_e3=reshape(S_e3,[25 30 30]);
    tensor_e3=tensor_e3./max(tensor_e3(:));
    tensor_e4=reshape(S_e4,[25 30 30]);
    tensor_e4=tensor_e4./max(tensor_e4(:));
    tensor_e5=reshape(S_e5,[25 30 30]);
    tensor_e5=tensor_e5./max(tensor_e5(:));
    Fourth_e(:,:,:,1)=tensor_e1;
    Fourth_e(:,:,:,2)=tensor_e2;
    Fourth_e(:,:,:,3)=tensor_e3;
    Fourth_e(:,:,:,4)=tensor_e4;
    Fourth_e(:,:,:,5)=tensor_e5;
    
    Fifth_tensor(:,:,:,:,1)=Fourth_a;
    Fifth_tensor(:,:,:,:,2)=Fourth_o;
    Fifth_tensor(:,:,:,:,3)=Fourth_e;
    
    % Tensor decomposition for feature extraction
    tic
    [Re_tensor, G, C, rse] = IGTN_decomp(Fifth_tensor,opts);
    Features(:,i)=C(:);
    error(i)=rse;
    toc
end