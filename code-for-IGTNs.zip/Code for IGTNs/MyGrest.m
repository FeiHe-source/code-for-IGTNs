function [Grest] = MyGrest(G, Ndim)
%% 生成本次Grest的模态积顺序index
indexG = zeros(1,Ndim);

for i = 1:(Ndim-2)
    indexG(i) = 2*i+1;
end

%% 按照上述指定的顺序进行张量缩并乘
for j = 1:(Ndim-2)%N阶张量的环因子去除最后一次缩并
    if j == 1
        Grest_temp = tensor_contraction(G{j},G{j+1},indexG(j),1);
    else
        Grest_temp = tensor_contraction(Grest_temp,G{j+1},indexG(j),1);
    end
end

%最后一次张量缩并
Grest = tensor_contraction(Grest_temp,G{Ndim},[(2*Ndim-1) 1],[1 3]);

%检查Grest的阶数是否正确
if ndims(Grest) ~= 2*Ndim
    disp('计算得到的Grest的阶数错误');
end

end

