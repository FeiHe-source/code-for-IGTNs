% This code is used to construct and decompose the 4th-order speech band
% tensors to extract features.

clear, clc;
close all;

% load data
load normal_data;
load unnormal_data;
 
Alldata=[normal_data; unnormal_data];
L=length(Alldata);
tensor_vowel=zeros(25,30,30,3);
label=[ones(1,40),zeros(1,46)];
num1=40;
num2=46;

% Hyperparameter settings of the decomposition models, in which only the 
% rank varies while all others remain fixed.
opts = [];
opts.tol   = 0.05;
opts.rho   = 0.1;
opts.maxit = 50;

% By adjusting the ranks, the connections of different edges can be
% controlled. The rank=1 means that the connection is cut.
opts.R = [1 1 1 1;
          8 8 8 8]; 
addpath(genpath([pwd,'/lib_IGTN']));
Features=zeros(opts.R(2,1)*opts.R(2,2)*opts.R(2,3)*opts.R(2,4),86);
error=zeros(1,86); 

for i=1:L
    fprintf('\tSubjectnum %d ', i);
    a=Alldata{i,1};
    L_stand=400000;
    fs=22050;
    
    % Resampling the signals to the same length and normalize them.
    L_a=length(a);
    re_fs=round(L_stand/L_a*fs);
    a=resample(a,re_fs,fs);
    a=a./max(abs(a));
    
    o=Alldata{i,2};
    L_o=length(o);
    re_fs=round(L_stand/L_o*fs);
    o=resample(o,re_fs,fs);
    o=o./max(abs(o));
    
    e=Alldata{i,3};
    L_e=length(e);
    re_fs=round(L_stand/L_e*fs);
    e=resample(e,re_fs,fs);
    e=e./max(abs(e));
    
    % The process of 4th-order speech band tensor construction
    window=fix(length(a)/500);
    S_a=spectrogram(a,window,400,512,44100);
    S_a=abs(real(S_a));
    S_a=S_a(1:25,1:900);
    tensor_a=reshape(S_a,[25 30 30]);
    
    S_o=spectrogram(o,window,400,512,44100);
    S_o=abs(real(S_o));
    S_o=S_o(1:25,1:900);
    tensor_o=reshape(S_o,[25 30 30]);
    
    S_e=spectrogram(e,window,400,512,44100);
    S_e=abs(real(S_e));
    S_e=S_e(1:25,1:900);
    tensor_e=reshape(S_e,[25 30 30]);
    
    tensor_a=tensor_a./max(tensor_a(:));
    tensor_o=tensor_o./max(tensor_o(:));
    tensor_e=tensor_e./max(tensor_e(:));
    tensor_vowel(:,:,:,1)=tensor_a;
    tensor_vowel(:,:,:,2)=tensor_o;
    tensor_vowel(:,:,:,3)=tensor_e;
    
    % Tensor decomposition for feature extraction
    tic
    tensor_vowel=permute(tensor_vowel,[1 3 2 4]);
    
    [Re_tensor, G, C, rse] = IGTN_decomp(tensor_vowel,opts);
    Features(:,i)=C(:);
    error(i)=rse;
    toc
end