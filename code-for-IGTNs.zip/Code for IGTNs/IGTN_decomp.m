function [X, G, Core, rse] = IGTN_decomp(F, opts)
if isfield(opts, 'tol');         tol   = opts.tol;              end 
if isfield(opts, 'maxit');       maxit = opts.maxit;            end
if isfield(opts, 'rho');         rho   = opts.rho;              end
if isfield(opts, 'R');           max_R = opts.R;                end

R = max_R;
Ndim = ndims(F); 
Nway = size(F);
X = F;
Factors_dims = factor_dims(Nway, R);
rng('default') 

% Initialization
G = cell(Ndim,1);
for i=1:Ndim
    G{i}=rand(Factors_dims(i,:)); 
end
Core = rand(R(2,:)); 
Out.RSE = [];
%
for k = 1:maxit
    % Update G_k, k=1,2,...,N.
    for num = 1:Ndim
        GCrest = tens2mat(MyGCrest(G,Core,num,Ndim), [Ndim+1,1,Ndim+2]);
        TempA  = tenmat_sb(F,num)*GCrest'+rho*my_Unfold(G{num},size(G{num}),2);
        TempB  = (GCrest*GCrest')+rho*eye(size(GCrest,1),size(GCrest,1)); % 其中eye函数返回单位矩
        G{num} = my_Fold(TempA*pinv(TempB),size(G{num}),2);  
     end
  
    % Update the core tensor C.
    Girest = tens2mat(MyGrest(G,Ndim), 2*(1:Ndim));
    if k==1  ||  mod(k, 2)==0
        TempC = reshape(X,[1,prod(Nway)])*Girest'+rho*reshape(Core,[1,numel(Core)]);
        TempD = (Girest*Girest')+rho*eye(size(Girest,1),size(Girest,1));
        Core2Vector = TempC*pinv(TempD);
        Core = mat2tens(Core2Vector,size(Core),[],1:Ndim);
    end
    
    % Update X 
    X = mat2tens(Core2Vector*Girest,size(X),[],1:Ndim);
    
    % Compute the reconstruction error of the speech tensors
    rse = norm(X(:)-F(:)) / norm(F(:));
    Out.RSE = [Out.RSE, rse];
    fprintf('inc_IGTN: iter = %d   RSE=%.10f   \n', k, rse);

    all_rse=Out.RSE;
    if k>3 && abs(all_rse(k)-all_rse(k-1))<0.00001
        break;
    end
    
end
end
